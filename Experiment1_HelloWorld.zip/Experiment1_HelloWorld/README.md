# Experiment 1 – Hello World Application

## Aim
To develop a simple Android application that displays the message **"Hello World"** on the screen using Android Studio.

---

## 1. Project Structure

```
Experiment1_HelloWorld/
├── build.gradle                          # Top-level Gradle config
├── settings.gradle                       # Module inclusion
├── gradle.properties
└── app/
    ├── build.gradle                      # App-level Gradle config
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/helloworld/
        │   └── MainActivity.java
        └── res/
            ├── layout/
            │   └── activity_main.xml
            └── values/
                ├── strings.xml
                └── themes.xml
```

---

## 2. Java Source File — `MainActivity.java`

See `app/src/main/java/com/example/helloworld/MainActivity.java`.

It extends `AppCompatActivity`, overrides `onCreate()`, and calls
`setContentView(R.layout.activity_main)` to inflate the XML layout.

---

## 3. XML Layout — `activity_main.xml`

A `ConstraintLayout` with a single `TextView` whose four constraint edges
(`top`, `bottom`, `start`, `end`) are all pinned to the parent, which
centers it both horizontally and vertically on the screen.

---

## 4. AndroidManifest.xml

Declares the app, its theme, and registers `MainActivity` as the
`LAUNCHER` activity (the one that opens when the app icon is tapped).

---

## 5. Step-by-Step Implementation

1. Open **Android Studio** → **New Project** → **Empty Views Activity** → Language: **Java**.
2. Name the project `Experiment1_HelloWorld`, package `com.example.helloworld`, minSdk 21.
3. Replace the generated `activity_main.xml` with the one provided here (centered `TextView`).
4. Add the string `hello_world_text` to `strings.xml`.
5. Replace `MainActivity.java` with the provided code (it only needs `setContentView`).
6. Connect a device/emulator (**Tools → Device Manager**) and click **Run ▶**.
7. Confirm "Hello World" appears centered on a blank screen.

*(Alternatively: unzip this folder as-is and open it directly in Android Studio via File → Open.)*

---

## 6. Explanation of the Code

- **`AppCompatActivity`**: base class providing backward-compatible UI behaviour.
- **`onCreate(Bundle savedInstanceState)`**: first lifecycle callback; where the UI is set up.
- **`setContentView(R.layout.activity_main)`**: inflates the XML layout and attaches it to the Activity's window.
- **`ConstraintLayout`**: a flat view hierarchy where each child's position is defined by constraints to siblings or the parent — here used to center the TextView without nested layouts.
- **`strings.xml`**: centralizes text so it isn't hard-coded (Android best practice, also required for translations).

---

## 7. Expected Output

On launch, the app shows a plain white screen with the bold text
**"Hello World"** centered exactly in the middle of the screen.

---

## 8. Viva Questions with Answers

| # | Question | Answer |
|---|----------|--------|
| 1 | What is an Activity in Android? | A single, focused screen with a UI that the user can interact with; the entry point for most apps. |
| 2 | What does `setContentView()` do? | It inflates the given XML layout resource and attaches the resulting View hierarchy as the Activity's UI. |
| 3 | What is `R.java`? | An auto-generated file that assigns unique integer IDs to every resource (layouts, strings, views, etc.) so they can be referenced from Java code. |
| 4 | Why use `ConstraintLayout` instead of `LinearLayout`? | It creates flatter, more performant view hierarchies and allows flexible, complex positioning (like true centering) without nesting multiple layouts. |
| 5 | What is the role of `AndroidManifest.xml`? | It declares the app's components (activities, services, etc.), permissions, and metadata the OS needs to run the app. |
| 6 | What is the difference between `dp` and `sp`? | `dp` (density-independent pixels) is used for layout dimensions; `sp` (scale-independent pixels) is used for text size, since it also respects the user's font-size accessibility setting. |
| 7 | What is `minSdkVersion`? | The lowest Android API level the app supports; the app will not install on devices below this version. |
| 8 | What is Gradle? | The build automation system Android Studio uses to compile code, manage dependencies, and package the APK. |

---

## 9. Common Errors & Troubleshooting

| Problem | Cause | Fix |
|---|---|---|
| "Cannot resolve symbol R" | Build not yet run, or XML syntax error | Click **Build → Rebuild Project**; fix any red XML errors first |
| Blank/white screen only | Layout not inflated | Confirm `setContentView(R.layout.activity_main)` is present in `onCreate()` |
| Gradle sync failed | No internet / wrong Gradle plugin version | Ensure internet access on first sync (downloads dependencies); use the AGP version listed in `build.gradle` or let Android Studio auto-upgrade it |
| App not installing on emulator | minSdk higher than emulator's API level | Create/select an emulator with API ≥ 21 |
