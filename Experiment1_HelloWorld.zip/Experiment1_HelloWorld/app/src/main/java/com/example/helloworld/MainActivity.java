package com.example.helloworld;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity - Entry point of the Hello World application.
 * Inflates activity_main.xml which contains a single centered TextView
 * displaying the text "Hello World".
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Attach the XML layout to this Activity
        setContentView(R.layout.activity_main);
    }
}
