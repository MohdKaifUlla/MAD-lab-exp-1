# Experiment 2 – Android Activity Lifecycle

## Aim
To understand the Android Activity Lifecycle by displaying lifecycle
methods using **Toast** messages and **Logcat**.

---

## 1. Project Structure

```
Experiment2_ActivityLifecycle/
├── build.gradle
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/lifecycledemo/
        │   ├── MainActivity.java
        │   └── SecondActivity.java        # helper activity to trigger pause/stop
        └── res/
            ├── layout/
            │   ├── activity_main.xml
            │   └── activity_second.xml
            └── values/
                ├── strings.xml
                └── themes.xml
```

`SecondActivity` is included purely as a lab tool: navigating to it and
back is the easiest reliable way to *force* `onPause()`/`onStop()` and
then `onRestart()`/`onStart()`/`onResume()` on `MainActivity` without
relying on the Home button (whose exact behaviour varies by device/OEM).

---

## 2. Java Source Files

- **`MainActivity.java`** — overrides all seven lifecycle callbacks
  (`onCreate`, `onStart`, `onResume`, `onPause`, `onStop`, `onRestart`,
  `onDestroy`), each logging via `Log.d(TAG, ...)` and showing a `Toast`.
- **`SecondActivity.java`** — a minimal activity with a "Back to Main"
  button; launching/closing it drives MainActivity through the
  background/foreground transitions.

---

## 3. XML Layout Files

- **`activity_main.xml`** — `LinearLayout` with a title `TextView`
  ("Android Activity Lifecycle Demo"), a button to launch
  `SecondActivity`, and a hint `TextView`.
- **`activity_second.xml`** — simple `LinearLayout` with a title and a
  "Back to Main" button.

---

## 4. AndroidManifest.xml

Registers both `MainActivity` (as `LAUNCHER`) and `SecondActivity`
(internal, `exported="false"`).

---

## 5. Step-by-Step Implementation

1. Create a new **Empty Views Activity** project named
   `Experiment2_ActivityLifecycle`, package `com.example.lifecycledemo`.
2. Replace `activity_main.xml` with the provided layout; add
   `activity_second.xml`.
3. Add `MainActivity.java` with all seven overridden lifecycle methods.
4. Create `SecondActivity.java` and register it in `AndroidManifest.xml`.
5. Run the app on an emulator/device.
6. Open **Logcat** in Android Studio and filter by tag
   `MainActivityLifecycle` (or `SecondActivityLifecycle`).
7. Perform these actions and observe both the Toasts and Logcat:
   - **App launch** → `onCreate → onStart → onResume`
   - **Tap "Go to Second Activity"** → `onPause → onStop`
   - **Tap "Back to Main"** → `onRestart → onStart → onResume`
   - **Press system Back from MainActivity** → `onPause → onStop → onDestroy`
   - **Rotate the device** → full destroy/recreate cycle:
     `onPause → onStop → onDestroy → onCreate → onStart → onResume`

---

## 6. Explanation of the Code

| Method | When it's called | Typical use |
|---|---|---|
| `onCreate()` | Activity is first created | Inflate layout, initialize views, restore saved state |
| `onStart()` | Activity becomes visible | Start UI-related resources (animations, etc.) |
| `onResume()` | Activity gains focus, user can interact | Resume camera/sensors, register listeners |
| `onPause()` | Activity partially obscured / losing focus | Pause animations, save lightweight state, release camera |
| `onStop()` | Activity no longer visible | Release heavier resources, stop location updates |
| `onRestart()` | Stopped Activity is about to be started again | Refresh data before `onStart()` runs |
| `onDestroy()` | Activity is being finally destroyed | Release all remaining resources, cancel background tasks |

`Log.d(TAG, message)` writes a debug-level entry visible in Logcat, and
`Toast.makeText(...).show()` displays a short pop-up on screen so the
transition is visible without needing to check Logcat.

---

## 7. Expected Output — Logcat (sample, filtered by `MainActivityLifecycle`)

```
D/MainActivityLifecycle: onCreate() called - Activity is being created
D/MainActivityLifecycle: onStart() called - Activity is becoming visible
D/MainActivityLifecycle: onResume() called - Activity is in foreground and interactive
--- user taps "Go to Second Activity" ---
D/MainActivityLifecycle: onPause() called - Activity is losing focus
D/MainActivityLifecycle: onStop() called - Activity is no longer visible
--- user taps "Back to Main" ---
D/MainActivityLifecycle: onRestart() called - Activity is restarting after being stopped
D/MainActivityLifecycle: onStart() called - Activity is becoming visible
D/MainActivityLifecycle: onResume() called - Activity is in foreground and interactive
--- user presses system Back ---
D/MainActivityLifecycle: onPause() called - Activity is losing focus
D/MainActivityLifecycle: onStop() called - Activity is no longer visible
D/MainActivityLifecycle: onDestroy() called - Activity is being destroyed
```

Corresponding Toast pop-ups appear on screen at each of these points.

---

## 8. Viva Questions with Answers

| # | Question | Answer |
|---|----------|--------|
| 1 | What are the seven lifecycle methods of an Activity? | `onCreate`, `onStart`, `onResume`, `onPause`, `onStop`, `onRestart`, `onDestroy`. |
| 2 | What is the difference between `onStop()` and `onDestroy()`? | `onStop()` means the Activity is invisible but may still exist in memory (can return via `onRestart`); `onDestroy()` means the Activity object is being permanently removed. |
| 3 | When is `onRestart()` called? | Only when an Activity is coming back into the foreground after having been stopped — never on the very first launch. |
| 4 | What happens to the lifecycle when the device is rotated? | By default, the Activity is destroyed and recreated (`onPause→onStop→onDestroy→onCreate→onStart→onResume`) so it can reload resources for the new configuration. |
| 5 | How can you preserve data across a configuration change? | Override `onSaveInstanceState(Bundle)` to save data and restore it in `onCreate()`/`onRestoreInstanceState()`, or use a `ViewModel`. |
| 6 | What is the difference between `onPause()` and `onStop()`? | `onPause()` fires when the Activity is losing focus but may still be partially visible (e.g., a dialog on top); `onStop()` fires once it's completely hidden. |
| 7 | Is it safe to do heavy work in `onPause()`? | No — `onPause()` must return quickly since the next Activity won't resume until it completes; heavy work belongs in `onStop()` or a background thread. |
| 8 | What is Logcat used for? | Viewing real-time system and app log output (`Log.d`, `Log.e`, etc.) for debugging. |

---

## 9. Common Errors & Troubleshooting

| Problem | Cause | Fix |
|---|---|---|
| Toasts not appearing | Emulator "Do Not Disturb" or Toast overlapping | Wait for previous Toast to finish, or check emulator notification settings |
| Logcat shows nothing | Wrong filter tag or wrong log level | Filter by `MainActivityLifecycle`, ensure log level is set to **Debug** or lower |
| `SecondActivity` crashes on launch | Not declared in `AndroidManifest.xml` | Add the `<activity android:name=".SecondActivity" />` entry |
| Lifecycle order looks "wrong" | Multitasking/animations can interleave calls between two activities | Always read the **tag**, not just message order, when both activities log simultaneously |
