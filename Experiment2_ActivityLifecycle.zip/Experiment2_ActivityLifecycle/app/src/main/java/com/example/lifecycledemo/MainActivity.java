package com.example.lifecycledemo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity demonstrates every method in the Android Activity Lifecycle.
 * Each lifecycle callback:
 *   1. Logs a message to Logcat under the tag "MainActivityLifecycle".
 *   2. Shows a short Toast so the lifecycle stage is visible on screen too.
 *
 * Lifecycle order on first launch:
 *   onCreate -> onStart -> onResume
 *
 * When another Activity is opened on top / Home is pressed:
 *   onPause -> onStop
 *
 * When the user returns to this Activity:
 *   onRestart -> onStart -> onResume
 *
 * When the Activity is finished / back-pressed from here:
 *   onPause -> onStop -> onDestroy
 */
public class MainActivity extends AppCompatActivity {

    // Tag used for all Log.d() calls - makes filtering Logcat easy
    private static final String TAG = "MainActivityLifecycle";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG, "onCreate() called - Activity is being created");
        Toast.makeText(this, "onCreate() called", Toast.LENGTH_SHORT).show();

        // Button navigates to SecondActivity to demonstrate onPause()/onStop()
        Button btnGoSecond = findViewById(R.id.btnGoSecond);
        btnGoSecond.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart() called - Activity is becoming visible");
        Toast.makeText(this, "onStart() called", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume() called - Activity is in foreground and interactive");
        Toast.makeText(this, "onResume() called", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause() called - Activity is losing focus");
        Toast.makeText(this, "onPause() called", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop() called - Activity is no longer visible");
        Toast.makeText(this, "onStop() called", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart() called - Activity is restarting after being stopped");
        Toast.makeText(this, "onRestart() called", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy() called - Activity is being destroyed");
        Toast.makeText(this, "onDestroy() called", Toast.LENGTH_SHORT).show();
    }
}
