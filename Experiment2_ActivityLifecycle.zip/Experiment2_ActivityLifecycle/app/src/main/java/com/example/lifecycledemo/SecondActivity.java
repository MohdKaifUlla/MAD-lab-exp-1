package com.example.lifecycledemo;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * SecondActivity is a helper Activity used only to push MainActivity
 * into the background (triggering onPause()/onStop()) and then bring it
 * back to the foreground (triggering onRestart()/onStart()/onResume())
 * when the user presses Back.
 */
public class SecondActivity extends AppCompatActivity {

    private static final String TAG = "SecondActivityLifecycle";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Log.d(TAG, "onCreate() called");
        Toast.makeText(this, "SecondActivity created", Toast.LENGTH_SHORT).show();

        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish()); // triggers MainActivity onRestart/onStart/onResume
    }
}
