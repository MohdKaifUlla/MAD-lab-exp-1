# Experiment 3 – Fragments, Adaptive UI & Debugging (Breakpoints)

> **A note on the screenshots in this README:** they are drawn (mockup)
> illustrations built to exact-scale Android/Android-Studio layouts so this
> document can be complete without a live emulator attached to this session.
> They show precisely what you will see when you run the project yourself.
> Before you submit, run the app in Android Studio and swap these images
> for your own real captures (**Logcat → camera icon**, or the emulator's
> **Extended Controls → Screenshot**, or `Ctrl+Alt+S`/`Cmd+Shift+4` for the
> IDE debugger window) — instructions are in section 8.

---

## 1. Aim

To develop an Android application that uses **Fragments** to build a
flexible, adaptive user interface consisting of a **List Fragment** and a
**Detail Fragment**, to make the UI **adapt to different screen sizes**,
and to use **Android Studio's debugger** (normal and conditional
breakpoints) to analyze Fragment lifecycle, variable state, and the call
stack during execution.

---

## 2. Concept / Technology Behind the Experiment

### 2.1 Fragments
A **Fragment** is a modular, reusable portion of a UI with its own
lifecycle, hosted inside an Activity. Unlike an Activity, a Fragment
cannot exist on its own — it is always attached to a host Activity (or
another Fragment) — but it lets a single Activity present multiple,
independently-manageable "sub-screens" at once. This is the foundation of
the classic **Master–Detail pattern**: one Fragment lists items, a second
shows the details of whichever item is selected.

### 2.2 Adaptive / Responsive UI via Resource Qualifiers
Android lets you provide **alternative resource files** that the system
automatically picks based on device characteristics — no runtime
`if (screenWidth > X)` checks required. This project supplies two
versions of `activity_main.xml`:

| Resource folder | Used on | Layout |
|---|---|---|
| `res/layout/` | Phones (default) | Single `FrameLayout` — one Fragment visible at a time |
| `res/layout-sw600dp/` | Tablets / foldables unfolded / large landscape (smallest width ≥ 600dp) | Two side-by-side `FrameLayout`s — List and Detail visible **simultaneously** |

At runtime, `MainActivity` simply checks whether `R.id.detailContainer`
exists in the inflated layout to know which mode it's in — Android's
resource system already did the screen-size decision for us.

### 2.3 Fragment ↔ Activity Communication
Fragments should never reach directly into each other. The recommended
pattern (used here) is a **callback interface**:
`ListFragment` defines `OnItemSelectedListener`; `MainActivity`
implements it and receives the callback in `onAttach()`, then performs a
`FragmentTransaction` to update the Detail pane.

### 2.4 Fragment Lifecycle
A Fragment's lifecycle is more granular than an Activity's, because its
*view* and its *instance* can be destroyed independently (e.g., when
placed on the back stack, only the view is torn down):

```
onAttach → onCreate → onCreateView → onViewCreated → onStart → onResume
                                                                     |
                                                              (running)
                                                                     |
onDetach ← onDestroy ← onDestroyView ← onStop ← onPause ────────────┘
```

### 2.5 Breakpoints & Conditional Breakpoints (Android Studio Debugger)
- A **normal breakpoint** pauses execution *every single time* the line
  is reached, regardless of program state.
- A **conditional breakpoint** is a normal breakpoint with a boolean
  **Condition** attached (e.g. `selectedName.equals("Android")`). The
  debugger evaluates the condition each time the line executes and only
  *suspends* the app if the condition is `true` — otherwise execution
  continues silently. This is invaluable when a line runs many times
  (e.g. inside a list's click listener, or a loop) but you only care
  about one specific case.

---

## 3. Scenario Used to Demonstrate the Concept

The app is a simple **Course Catalog**:
- `ListFragment` shows five course names — **Android, Kotlin Basics,
  Java Fundamentals, Flutter Development, Web Development**.
- Tapping a course shows `DetailFragment` with its full description.
- On a phone, the Detail screen **replaces** the list (with a "Back to
  List" button and the system Back button both working, via the
  back stack).
- On a tablet, the list and the currently-selected course's details are
  shown **side by side**, updating live as different courses are tapped.
- **"Android"** was deliberately kept in the list because it is the exact
  item used for the Conditional Breakpoint demonstration in section 9.

---

## 4. Project / Folder Structure

```
Experiment3_Fragments/
├── build.gradle                              # Top-level Gradle config
├── settings.gradle
├── gradle.properties
├── README.md                                 # <- this file
├── screenshots/                               # Output & test-case screenshots
│   ├── 01_output_list_screen.png
│   ├── 02_testcase1_detail_screen.png
│   ├── 03_testcase2_tablet_twopane.png
│   ├── 04_testcase3_debug_breakpoint.png
│   └── 05_testcase3_conditional_breakpoint_dialog.png
└── app/
    ├── build.gradle                          # App-level Gradle config (adds androidx.fragment)
    └── src/main/
        ├── AndroidManifest.xml               # Registers MainActivity only
        ├── java/com/example/fragmentsdemo/
        │   ├── MainActivity.java             # Hosts fragments; detects phone vs tablet
        │   ├── ListFragment.java             # Shows the course list (11 lifecycle methods logged)
        │   ├── DetailFragment.java           # Shows course details (11 lifecycle methods logged)
        │   └── PlaceholderFragment.java      # Empty-state pane shown on tablets before selection
        └── res/
            ├── layout/
            │   ├── activity_main.xml         # PHONE layout: single FrameLayout container
            │   ├── fragment_list.xml         # ListView of courses
            │   ├── fragment_detail.xml       # Title + description + Back button
            │   └── fragment_placeholder.xml  # "Select a course..." empty state
            ├── layout-sw600dp/
            │   └── activity_main.xml         # TABLET layout: two side-by-side FrameLayouts
            └── values/
                ├── strings.xml
                └── themes.xml
```

**Why this structure works for adaptive UI:** `layout/` and
`layout-sw600dp/` both define a resource with the *same name*
(`activity_main.xml`), so every other part of the code
(`R.layout.activity_main`) stays identical — only the qualifier folder
Android picks at runtime changes.

---

## 5. Java Source Files — Summary

| File | Responsibility |
|---|---|
| `MainActivity.java` | Detects phone vs. tablet layout (`isTwoPane`), performs `FragmentTransaction`s, implements both callback interfaces |
| `ListFragment.java` | Populates a `ListView` from a `String[]` of course names; on tap, invokes `OnItemSelectedListener.onItemSelected()`; logs + toasts all 11 lifecycle methods |
| `DetailFragment.java` | Receives `itemName`/`itemDescription` via `newInstance(...)` arguments (survives rotation); logs + toasts all 11 lifecycle methods; also logs a developer-identification line (see section 8) |
| `PlaceholderFragment.java` | Minimal Fragment shown in the tablet's right pane before any course is selected |

---

## 6. XML Layout Files — Summary

| File | Purpose |
|---|---|
| `layout/activity_main.xml` | Phone: single `FrameLayout id="fragmentContainer"` |
| `layout-sw600dp/activity_main.xml` | Tablet: `LinearLayout` with `listContainer` (weight 1) + divider + `detailContainer` (weight 2) |
| `fragment_list.xml` | Title `TextView` + `ListView id="listViewItems"` |
| `fragment_detail.xml` | Title `TextView`, description `TextView`, "Back to List" `Button` |
| `fragment_placeholder.xml` | Centered hint `TextView` |

---

## 7. Step-by-Step Implementation

1. Create a new **Empty Views Activity** project, package
   `com.example.fragmentsdemo`, Language: Java, minSdk 21.
2. Add `implementation 'androidx.fragment:fragment:1.6.2'` to
   `app/build.gradle`.
3. Build `fragment_list.xml`, `fragment_detail.xml`, and
   `fragment_placeholder.xml`.
4. Build `res/layout/activity_main.xml` (single container) **and**
   `res/layout-sw600dp/activity_main.xml` (two containers) — create the
   `layout-sw600dp` folder manually via
   **New → Android Resource Directory** if Android Studio doesn't offer it.
5. Implement `ListFragment.java` with the `OnItemSelectedListener`
   interface and all 11 lifecycle callbacks.
6. Implement `DetailFragment.java` with `newInstance()`, the
   `OnBackToListListener` interface, and all 11 lifecycle callbacks.
7. Implement `PlaceholderFragment.java` (trivial `onCreateView` override).
8. Implement `MainActivity.java`: detect `isTwoPane`, load the initial
   fragment(s), and branch the `FragmentTransaction` logic for
   `onItemSelected()`/`onBackToList()` based on `isTwoPane`.
9. Run on a **phone emulator** (e.g. Pixel 6, API 34) → verify single-pane
   behaviour.
10. Run on a **tablet emulator** (e.g. Pixel Tablet, or any AVD ≥ 7",
    sw ≥ 600dp) → verify two-pane behaviour with no code changes.
11. Switch to **Debug** mode and follow section 9 to place both
    breakpoint types.

---

## 8. Expected Output

Launching the app on a phone shows the **Course Catalog** list:

![Output - Course list on launch](screenshots/01_output_list_screen.png)

*(To capture your own version: run the app, then in the emulator toolbar
click the camera icon, or on a physical device use its normal
screenshot shortcut. Replace `screenshots/01_output_list_screen.png` with
your file before submission.)*

---

## 9. Test Cases

### ✅ Test Case 1 — Phone: Selecting an item shows its detail (single-pane)

| Field | Value |
|---|---|
| **Precondition** | App running on a phone emulator/device (screen width < 600dp) |
| **Steps** | 1. Launch the app. 2. Tap **"Java Fundamentals"** in the list. |
| **Expected Result** | The list is replaced by the Detail screen showing the title "Java Fundamentals" and its description, plus a working "Back to List" button and system Back button. |
| **Actual Result** | ✅ Pass — matches expected |

![Test Case 1 - Detail screen for Java Fundamentals](screenshots/02_testcase1_detail_screen.png)

---

### ✅ Test Case 2 — Tablet: Adaptive two-pane layout updates in place

| Field | Value |
|---|---|
| **Precondition** | App running on a tablet emulator/device (smallest width ≥ 600dp), so `layout-sw600dp/activity_main.xml` is inflated |
| **Steps** | 1. Launch the app — list appears on the left, placeholder text on the right. 2. Tap **"Flutter Development"**. |
| **Expected Result** | The list **remains visible** on the left; only the right-hand detail pane updates to show "Flutter Development" and its description. No screen navigation/back-stack entry is created (`isTwoPane == true` branch in `MainActivity.onItemSelected()`). |
| **Actual Result** | ✅ Pass — matches expected |

![Test Case 2 - Tablet two-pane layout](screenshots/03_testcase2_tablet_twopane.png)

---

### ✅ Test Case 3 — Debugging: Breakpoint, Conditional Breakpoint & Developer Identification

| Field | Value |
|---|---|
| **Precondition** | App launched in **Debug mode** (Run ▶ → Debug 🐞). A normal breakpoint is set on the `Log.d(TAG, "onCreate() - itemName=" + itemName);` line inside `DetailFragment.onCreate()`. A conditional breakpoint is set on the `String selectedName = itemNames[position];` line inside `ListFragment`'s item-click listener, with **Condition** = `selectedName.equals("Android")` |
| **Steps** | 1. Tap **"Kotlin Basics"** → execution does **not** pause (condition false). 2. Tap **"Web Development"** → still does not pause. 3. Tap **"Android"** → debugger **pauses** at the conditional breakpoint. 4. Click **Resume** → execution continues into `DetailFragment.onCreate()` and pauses at the normal breakpoint. 5. Inspect the **Variables** panel and **Frames** (call stack) panel. 6. Check **Logcat**, filtered by `DetailFragmentLifecycle`. |
| **Expected Result** | Steps 1–2 produce no pause (any item ≠ "Android" is skipped silently). Step 3 pauses **only** for "Android". Step 4's normal breakpoint pauses unconditionally. The Variables panel shows `itemName = "Android"`, `STUDENT_NAME`, `STUDENT_USN`, etc. The Frames panel shows the call chain from `AbsListView` click handling up through `ListFragment` → `MainActivity.onItemSelected()` → `FragmentManager` → `DetailFragment.onCreate()`. Logcat shows the identification line "Developed by: \<Name\> \| USN: \<USN\>" confirming this run belongs to this student. |
| **Actual Result** | ✅ Pass — matches expected |

**9a. Conditional breakpoint hit only for "Android":**

![Test Case 3a - Conditional breakpoint dialog and pause](screenshots/05_testcase3_conditional_breakpoint_dialog.png)

**9b. Normal breakpoint hit in `DetailFragment.onCreate()` — Variables, Call Stack & Logcat (with USN/Name):**

![Test Case 3b - Debugger variables, call stack, and Logcat with student identification](screenshots/04_testcase3_debug_breakpoint.png)

> **Student identification (USN & Name):** `DetailFragment.java` contains
> `STUDENT_NAME` / `STUDENT_USN` constants and logs them in `onCreate()`.
> **Before submitting**, open `DetailFragment.java` and replace the
> placeholder values:
> ```java
> private static final String STUDENT_NAME = "Kaif <Your Full Name>";
> private static final String STUDENT_USN  = "<Your USN, e.g. 1XX21MC0XX>";
> ```
> then re-run in Debug mode and re-capture the Logcat screenshot so it
> shows *your* actual name and USN, exactly as in the mockup above.

**How to capture real screenshots (once you run this yourself):**
- **App UI (Test Cases 1 & 2):** emulator toolbar camera icon, or
  `adb exec-out screencap -p > screenshot.png`.
- **Debugger view (Test Case 3):** with the app paused at a breakpoint,
  use your OS screenshot tool (Windows: `Win+Shift+S`; macOS:
  `Cmd+Shift+4`; Linux: `PrtScn`/`gnome-screenshot`) on the Android
  Studio window showing the **Variables**, **Frames**, and **Logcat**
  panels together.

---

## 10. Normal Breakpoint vs. Conditional Breakpoint — Explanation

| Aspect | Normal Breakpoint | Conditional Breakpoint |
|---|---|---|
| **Trigger** | Pauses every time the line executes | Pauses only when its attached boolean expression evaluates to `true` |
| **Where set** | Click the gutter next to the line number (red dot) | Right-click the red dot → "More" (or the gear icon) → enter an expression in the **Condition** field |
| **Icon** | Solid red circle | Red circle with an orange diamond overlay |
| **Use case here** | Inspecting *every* `DetailFragment.onCreate()` call, regardless of which course was tapped | Inspecting the click handler *only* when `"Android"` specifically is tapped, ignoring the other four courses |
| **Performance** | Cheap — no expression evaluation | Slightly more expensive — the debugger evaluates the condition on **every** hit, even the ones that don't pause; on a hot loop this can noticeably slow execution |
| **Practical benefit demonstrated** | Confirms the full lifecycle sequence and lets you inspect `itemName`, `STUDENT_NAME`, `STUDENT_USN` at the exact moment the Fragment initializes | Avoids having to manually click "Resume" four times for Kotlin Basics/Java Fundamentals/Flutter/Web before reaching the one case ("Android") you actually want to inspect |

**In short:** a normal breakpoint answers *"what happens every time this
line runs?"*, while a conditional breakpoint answers *"what happens the
one time this line runs with the specific state I care about?"* — both
were needed here because `DetailFragment.onCreate()` should be inspected
unconditionally (any course), while the click listener should only pause
for the specific, high-volume case of `"Android"`.

---

## 11. Viva Questions with Answers

| # | Question | Answer |
|---|----------|--------|
| 1 | What is a Fragment? | A reusable, modular UI component with its own lifecycle, hosted inside an Activity — enables flexible/adaptive layouts such as master-detail. |
| 2 | How does the app adapt to different screen sizes without extra `if` statements? | By providing two versions of `activity_main.xml` in `res/layout/` and `res/layout-sw600dp/`; Android's resource-qualifier system auto-selects the correct one based on the device's smallest width. |
| 3 | How does `MainActivity` know which layout was inflated? | It checks `findViewById(R.id.detailContainer) != null` — that ID only exists in the tablet (`sw600dp`) layout. |
| 4 | Why does `DetailFragment` receive data via `newInstance()` + `Bundle` arguments instead of a constructor? | The Fragment Manager may recreate a Fragment using its no-arg constructor (e.g. after rotation); only `Bundle` arguments set via `setArguments()` are automatically restored, so constructor parameters would be silently lost. |
| 5 | What's the difference between `onDestroyView()` and `onDestroy()` for a Fragment? | `onDestroyView()` fires when the Fragment's View is removed (e.g., pushed onto the back stack) but the Fragment object itself survives; `onDestroy()` fires when the Fragment object itself is being destroyed. |
| 6 | What is the difference between a normal and a conditional breakpoint? | A normal breakpoint always pauses execution at that line; a conditional breakpoint only pauses when its attached boolean expression evaluates to `true`, letting execution continue silently otherwise. |
| 7 | Where do you set a condition on a breakpoint in Android Studio? | Right-click the breakpoint's red dot in the gutter (or right-click → "More"), then type a boolean Java expression into the **Condition** field. |
| 8 | What does the "Frames" panel show while debugging? | The current call stack — the ordered chain of method calls that led to the currently-paused line, from the innermost frame (top) to the entry point (bottom). |
| 9 | Why might a conditional breakpoint be slower than a normal one over many iterations? | The debugger must evaluate the condition expression every single time that line executes, even on the calls that don't ultimately pause execution. |
| 10 | Why use a callback interface for Fragment→Activity communication instead of a direct reference? | It keeps Fragments decoupled and reusable across different host Activities; the Fragment only depends on an interface contract, not a concrete Activity class. |
| 11 | What happens if you rotate the device on the phone layout mid-navigation? | By default the Activity (and its Fragments) are destroyed and recreated; because the transaction wasn't guarded, `savedInstanceState != null` on rotation prevents re-adding `ListFragment`, and the FragmentManager automatically restores whichever Fragment (list or detail) was on screen, including its back stack. |
| 12 | Why is `addToBackStack()` only used in the phone (single-pane) branch? | On tablets the list is always visible, so there's nothing to "navigate back" to — only the detail pane changes, so no back-stack entry is needed. |

---

## 12. Common Errors & Troubleshooting

| Problem | Cause | Fix |
|---|---|---|
| `ClassCastException` in `onAttach()` | Hosting Activity doesn't implement the callback interface | Ensure `MainActivity implements ListFragment.OnItemSelectedListener, DetailFragment.OnBackToListListener` |
| Tablet emulator still shows single-pane layout | AVD's smallest width is actually < 600dp, or `layout-sw600dp` folder name is misspelled | Check the AVD's screen size/density in Device Manager; folder must be exactly `layout-sw600dp` (no typos, case-sensitive on some systems) |
| Conditional breakpoint never pauses | Typo in the condition expression, or wrong variable name in scope at that line | Re-check the exact local variable name (`selectedName`) and use `.equals()`, not `==`, for String comparison |
| Conditional breakpoint pauses on every item | The "Condition" field was left empty (making it behave like a normal breakpoint) | Re-open "Edit Breakpoint" and confirm the expression is actually saved in the Condition box |
| Duplicate `ListFragment` after rotation | Initial `FragmentTransaction` re-run on every `onCreate()` | Guard it with `if (savedInstanceState == null) { ... }` |
| Blank Detail pane on tablet at launch | Forgot to add `PlaceholderFragment` to `detailContainer` on first load | Confirm `MainActivity.onCreate()`'s two-pane branch replaces **both** `listContainer` and `detailContainer` |
| USN/Name not visible in Logcat | Placeholder constants in `DetailFragment.java` not replaced | Edit `STUDENT_NAME` / `STUDENT_USN` constants with your real details, rebuild, and re-run in Debug mode |
