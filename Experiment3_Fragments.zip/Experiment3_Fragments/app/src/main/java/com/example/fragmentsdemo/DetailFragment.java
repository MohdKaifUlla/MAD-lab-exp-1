package com.example.fragmentsdemo;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * DetailFragment displays the name and description of the item selected
 * in ListFragment. The selected data is passed in via Fragment arguments
 * (Bundle) using the standard newInstance() factory-method pattern,
 * which survives configuration changes correctly (unlike constructor args).
 *
 * All lifecycle methods are logged and shown as Toasts, and the current
 * value of the "itemName" argument is logged at each stage to demonstrate
 * how Fragment state persists across the lifecycle.
 */
public class DetailFragment extends Fragment {

    private static final String TAG = "DetailFragmentLifecycle";
    private static final String ARG_ITEM_NAME = "arg_item_name";
    private static final String ARG_ITEM_DESC = "arg_item_desc";

    // Developer identification (printed to Logcat in onCreate() below).
    // TODO: replace with your own details before submission/screenshot.
    private static final String STUDENT_NAME = "Kaif <Your Full Name>";
    private static final String STUDENT_USN = "<Your USN, e.g. 1XX21MC0XX>";

    private String itemName;
    private String itemDescription;

    public interface OnBackToListListener {
        void onBackToList();
    }

    private OnBackToListListener listener;

    public DetailFragment() {
        // Required empty public constructor
    }

    /**
     * Factory method - the recommended way to create a Fragment with
     * initial arguments so they are automatically restored on rotation.
     */
    public static DetailFragment newInstance(String itemName, String itemDescription) {
        DetailFragment fragment = new DetailFragment();
        Bundle args = new Bundle();
        args.putString(ARG_ITEM_NAME, itemName);
        args.putString(ARG_ITEM_DESC, itemDescription);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        Log.d(TAG, "onAttach() - Fragment attached to Activity");
        Toast.makeText(context, "DetailFragment: onAttach()", Toast.LENGTH_SHORT).show();

        if (context instanceof OnBackToListListener) {
            listener = (OnBackToListListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnBackToListListener");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Read arguments here; this is the correct lifecycle stage for it
        if (getArguments() != null) {
            itemName = getArguments().getString(ARG_ITEM_NAME);
            itemDescription = getArguments().getString(ARG_ITEM_DESC);
        }
        Log.d(TAG, "onCreate() - itemName=" + itemName);          // <- put a NORMAL Breakpoint HERE
        Log.d(TAG, "Developed by: " + STUDENT_NAME + " | USN: " + STUDENT_USN);
        Toast.makeText(getContext(), "DetailFragment: onCreate()", Toast.LENGTH_SHORT).show();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView() - Inflating fragment_detail.xml, itemName=" + itemName);
        Toast.makeText(getContext(), "DetailFragment: onCreateView()", Toast.LENGTH_SHORT).show();
        return inflater.inflate(R.layout.fragment_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d(TAG, "onViewCreated() - Binding data to views, itemName=" + itemName);
        Toast.makeText(getContext(), "DetailFragment: onViewCreated()", Toast.LENGTH_SHORT).show();

        TextView tvTitle = view.findViewById(R.id.tvDetailTitle);
        TextView tvDescription = view.findViewById(R.id.tvDetailDescription);
        Button btnBack = view.findViewById(R.id.btnBackToList);

        tvTitle.setText(itemName);
        tvDescription.setText(itemDescription);

        btnBack.setOnClickListener(v -> {
            if (listener != null) {
                listener.onBackToList();
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart() - Fragment becoming visible, itemName=" + itemName);
        Toast.makeText(getContext(), "DetailFragment: onStart()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume() - Fragment is now interactive, itemName=" + itemName);
        Toast.makeText(getContext(), "DetailFragment: onResume()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause() - Fragment losing focus, itemName=" + itemName);
        Toast.makeText(getContext(), "DetailFragment: onPause()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop() - Fragment no longer visible, itemName=" + itemName);
        Toast.makeText(getContext(), "DetailFragment: onStop()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.d(TAG, "onDestroyView() - View hierarchy destroyed, itemName still held=" + itemName);
        Toast.makeText(getContext(), "DetailFragment: onDestroyView()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy() - Fragment being destroyed, itemName=" + itemName);
        Toast.makeText(getContext(), "DetailFragment: onDestroy()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        Log.d(TAG, "onDetach() - Fragment detached from Activity, clearing listener");
        listener = null;
    }
}
