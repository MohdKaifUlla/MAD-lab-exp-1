package com.example.fragmentsdemo;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * ListFragment displays a list of fruit names. When an item is tapped it
 * notifies the hosting Activity via the OnItemSelectedListener callback
 * interface (the standard Fragment -> Activity communication pattern).
 *
 * Every lifecycle method is logged and shown as a Toast so the complete
 * Fragment lifecycle sequence can be observed in Logcat.
 */
public class ListFragment extends Fragment {

    private static final String TAG = "ListFragmentLifecycle";

    // Sample data: course name -> description.
    // NOTE: "Android" is included deliberately - it is the item used later
    // for the Conditional Breakpoint demonstration (see README section 9).
    private final String[] itemNames = {
            "Android", "Kotlin Basics", "Java Fundamentals",
            "Flutter Development", "Web Development"
    };
    private final String[] itemDescriptions = {
            "Android: Build native mobile apps for phones, tablets and wearables using the Android SDK.",
            "Kotlin Basics: Learn the modern, concise, null-safe language officially preferred for Android.",
            "Java Fundamentals: Core object-oriented programming concepts used across enterprise and Android development.",
            "Flutter Development: Google's UI toolkit for building natively compiled apps from a single Dart codebase.",
            "Web Development: HTML, CSS and JavaScript fundamentals for building responsive websites."
    };

    // Callback interface implemented by the hosting Activity
    public interface OnItemSelectedListener {
        void onItemSelected(String itemName, String itemDescription);
    }

    // Reference to the listener (the hosting Activity)
    private OnItemSelectedListener listener;

    // Required empty public constructor
    public ListFragment() {
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        Log.d(TAG, "onAttach() - Fragment attached to Activity");
        Toast.makeText(context, "ListFragment: onAttach()", Toast.LENGTH_SHORT).show();

        // Safely cast the hosting context to our callback interface
        if (context instanceof OnItemSelectedListener) {
            listener = (OnItemSelectedListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnItemSelectedListener");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate() - Fragment instance created, variables can be initialized here");
        Toast.makeText(getContext(), "ListFragment: onCreate()", Toast.LENGTH_SHORT).show();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView() - Inflating fragment_list.xml");
        Toast.makeText(getContext(), "ListFragment: onCreateView()", Toast.LENGTH_SHORT).show();
        return inflater.inflate(R.layout.fragment_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d(TAG, "onViewCreated() - View hierarchy ready, safe to access widgets now");
        Toast.makeText(getContext(), "ListFragment: onViewCreated()", Toast.LENGTH_SHORT).show();

        ListView listView = view.findViewById(R.id.listViewItems);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(), android.R.layout.simple_list_item_1, itemNames);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, v, position, id) -> {
            // selectedName is the value used for the Conditional Breakpoint demo:
            // right-click the line below in Android Studio's gutter -> "More" ->
            // set Condition to:  selectedName.equals("Android")
            // Execution will then pause ONLY when "Android" is tapped, and will
            // silently skip every other item (see README section 9).
            String selectedName = itemNames[position];               // <- put breakpoint HERE
            String selectedDescription = itemDescriptions[position];
            Log.d(TAG, "Item clicked: " + selectedName + " (position=" + position + ")");
            // Notify the hosting Activity through the callback interface
            if (listener != null) {
                listener.onItemSelected(selectedName, selectedDescription);
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart() - Fragment becoming visible");
        Toast.makeText(getContext(), "ListFragment: onStart()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume() - Fragment is now interactive (in foreground)");
        Toast.makeText(getContext(), "ListFragment: onResume()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause() - Fragment losing foreground/interactive state");
        Toast.makeText(getContext(), "ListFragment: onPause()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop() - Fragment no longer visible");
        Toast.makeText(getContext(), "ListFragment: onStop()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.d(TAG, "onDestroyView() - View hierarchy is being removed; release view references here");
        Toast.makeText(getContext(), "ListFragment: onDestroyView()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy() - Fragment state is being cleaned up");
        Toast.makeText(getContext(), "ListFragment: onDestroy()", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        Log.d(TAG, "onDetach() - Fragment detached from Activity, listener reference cleared");
        // Note: Context is not available here, so no Toast is shown in onDetach()
        listener = null;
    }
}
