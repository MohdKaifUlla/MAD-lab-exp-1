package com.example.fragmentsdemo;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

/**
 * MainActivity hosts the Fragments and adapts its behaviour to the
 * screen size Android chose a layout for:
 *
 *  - Phone (res/layout/activity_main.xml): a single FrameLayout
 *    ("fragmentContainer"). ListFragment and DetailFragment are shown
 *    one at a time; navigating to DetailFragment is added to the
 *    back stack so the system Back button returns to the list.
 *
 *  - Tablet / large screen, smallest-width >= 600dp
 *    (res/layout-sw600dp/activity_main.xml): two FrameLayouts
 *    ("listContainer" + "detailContainer") side by side. Both
 *    Fragments are visible simultaneously; selecting an item simply
 *    updates the detail pane in place (no back stack needed, since
 *    the list never leaves the screen).
 *
 * Which layout got inflated is detected purely by checking whether
 * R.id.detailContainer exists - no manual screen-width math needed;
 * Android's resource-qualifier system already did that for us.
 */
public class MainActivity extends AppCompatActivity
        implements ListFragment.OnItemSelectedListener, DetailFragment.OnBackToListListener {

    private static final String TAG = "MainActivity";

    // True when layout-sw600dp/activity_main.xml was inflated (tablet / large screen)
    private boolean isTwoPane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate: Activity created");

        // detailContainer only exists in the sw600dp two-pane layout
        isTwoPane = findViewById(R.id.detailContainer) != null;
        Log.d(TAG, "onCreate: isTwoPane = " + isTwoPane);

        if (savedInstanceState == null) {
            if (isTwoPane) {
                // Tablet: list on the left, an empty-state placeholder on the right
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.listContainer, new ListFragment(), "LIST_FRAGMENT")
                        .replace(R.id.detailContainer, new PlaceholderFragment(), "PLACEHOLDER_FRAGMENT")
                        .commit();
            } else {
                // Phone: list fills the single container
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragmentContainer, new ListFragment(), "LIST_FRAGMENT")
                        .commit();
            }
        }
    }

    /**
     * Called by ListFragment when the user taps a course.
     */
    @Override
    public void onItemSelected(String itemName, String itemDescription) {
        Log.d(TAG, "onItemSelected: " + itemName + " (isTwoPane=" + isTwoPane + ")");

        DetailFragment detailFragment = DetailFragment.newInstance(itemName, itemDescription);
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction();

        if (isTwoPane) {
            // Tablet: just refresh the right-hand pane; list stays visible, no back stack.
            transaction.replace(R.id.detailContainer, detailFragment, "DETAIL_FRAGMENT");
        } else {
            // Phone: replace the whole screen and remember how to get back.
            transaction.replace(R.id.fragmentContainer, detailFragment, "DETAIL_FRAGMENT");
            transaction.addToBackStack(null);
        }
        transaction.commit();
    }

    /**
     * Called by DetailFragment's "Back to List" button (phone layout only;
     * the button is hidden from the user's flow on tablets since the list
     * is always visible, but the callback is still safely handled here).
     */
    @Override
    public void onBackToList() {
        Log.d(TAG, "onBackToList (isTwoPane=" + isTwoPane + ")");
        if (isTwoPane) {
            // Nothing to navigate back to - just clear the detail pane.
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.detailContainer, new PlaceholderFragment())
                    .commit();
        } else {
            getSupportFragmentManager().popBackStack();
        }
    }
}
