package com.example.fragmentsdemo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * A very small Fragment used only to occupy the detail pane on large
 * (two-pane / tablet) screens before the user has selected any course.
 * It has no lifecycle logging of its own since it is not part of the
 * lifecycle/debugging demonstration - only ListFragment and
 * DetailFragment are.
 */
public class PlaceholderFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_placeholder, container, false);
    }
}
